from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(
    [
        Requestor,
        Quotation,
        QuotationDetail,
        QuotationTestParameter,
        QuoteionObjectDimension,
        Geometry,
        File,
    ]
)
