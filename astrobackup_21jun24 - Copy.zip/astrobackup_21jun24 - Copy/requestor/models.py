from django.db import models


class Requestor(models.Model):
    user = models.OneToOneField("authentication.User", on_delete=models.CASCADE)

    def __str__(self):
        return self.user.email


class Organization(models.Model):
    requestor = models.OneToOneField(Requestor, on_delete=models.DO_NOTHING)
    name = models.CharField(max_length=255)
    email = models.EmailField(unique=True)
    address = models.CharField(max_length=250, null=True, blank=True)
    established_date = models.DateField()

    def __str__(self):
        return self.email


class Quotation(models.Model):
    requestor = models.OneToOneField(Requestor, on_delete=models.CASCADE)
    date_created = models.DateField(auto_now_add=True)
    status = models.ForeignKey(
        "utility.QuotationStatus", on_delete=models.SET_NULL, null=True
    )
    base_metal_alloy = models.CharField(max_length=250)
    alloy = models.CharField(max_length=250)

    def __str__(self):
        return str(self.Requestor)


class QuotationDetail(models.Model):
    quotation = models.ForeignKey(Quotation, on_delete=models.CASCADE)
    test = models.ForeignKey("director.Test", on_delete=models.CASCADE)
    test_condition = models.ForeignKey("director.Condition", on_delete=models.CASCADE)
    test_condition_value = models.CharField(max_length=250)
    test_object = models.ForeignKey("director.TestObject", on_delete=models.CASCADE)
    test_object_quantity = models.IntegerField()
    unit_dimension = models.ForeignKey(
        "utility.UnitDimension", on_delete=models.CASCADE
    )

    def __str__(self):
        return f"{self.test_object} - {self.quotation}"


class Geometry(models.Model):
    quotation = models.ForeignKey(Quotation, on_delete=models.CASCADE)
    description = models.TextField(max_length=500)

    def __str__(self):
        return self.description


class File(models.Model):
    Geometry = models.ForeignKey(Geometry, on_delete=models.CASCADE)
    File = models.FileField()

    def __str__(self):
        return f"File {self.id}"


class QuotationTestParameter(models.Model):
    quotetion_detail = models.ForeignKey(QuotationDetail, on_delete=models.CASCADE)
    test_parameter = models.ForeignKey(
        "director.TestParameter", on_delete=models.CASCADE
    )
    test_parameter_value = models.CharField(max_length=250)
    unit_dimension = models.ForeignKey(
        "utility.UnitDimension", on_delete=models.CASCADE
    )

    def __str__(self):
        return f"{self.test_parameter} - {self.quotetion_detail}"


class QuoteionObjectDimension(models.Model):
    quotation_detail = models.ForeignKey(QuotationDetail, on_delete=models.CASCADE)
    unit_dimension = models.ForeignKey(
        "utility.UnitDimension", on_delete=models.CASCADE
    )
    dimension_value = models.CharField(max_length=250)

    def __str__(self):
        return f"{self.unit_dimension.name} - {self.quotation_detail}"
