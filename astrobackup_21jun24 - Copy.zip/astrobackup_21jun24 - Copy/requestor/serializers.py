from xml.dom import ValidationErr
from rest_framework import serializers
# from . models import Requestor, Organization, User, Role
from . models import *
from authentication .models import Role, User
from rest_framework.response import Response
from requestor .utils import Util

        # 18Jul24 at 01:37PM

from django.contrib.auth.tokens import default_token_generator
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
# from django.utils.encoding import smart_str, smart_unicode
# from django.utils.encoding import force_bytes, force_str
from django.utils.encoding import smart_str, force_bytes, DjangoUnicodeDecodeError
from django.template.loader import render_to_string
from django.contrib.auth.tokens import PasswordResetTokenGenerator
from django.core.mail import send_mail
from django.conf import settings

class OrganizationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Organization
        fields = ['name', 'email', 'address', 'established_date']

class RequestorSerializer(serializers.ModelSerializer):
    # organization = OrganizationSerializer(required=False)
    email = serializers.EmailField(source='user.email')
    first_name = serializers.CharField(source='user.first_name')
    last_name = serializers.CharField(source='user.last_name')
    password = serializers.CharField(write_only=True, source='user.password')
    organization = OrganizationSerializer(required=False)

    class Meta:
        model = Requestor
        fields = ['first_name', 'last_name', 'email', 'password', 'organization']

    def create(self, validated_data):
        user_data = validated_data.pop('user')
        organization_data = validated_data.pop('organization', None)
        user = User.objects.create_user(**user_data)
        
        requestor = Requestor.objects.create(user=user)
        
        if organization_data:
            Organization.objects.create(requestor=requestor, **organization_data)
        
        requestor_role, created = (Role.objects.get_or_create(name='REQUESTOR'))
        user.role.add(requestor_role)
        
        return requestor

    def update(self, instance, validated_data):
        user_data = validated_data.pop('user', {})
        organization_data = validated_data.pop('organization', {})

        # Update user fields
        user = instance.user
        user.email = user_data.get('email', user.email)
        user.first_name = user_data.get('first_name', user.first_name)
        user.last_name = user_data.get('last_name', user.last_name)
        if 'password' in user_data:
            user.set_password(user_data['password'])
        user.save()

        # Update or create organization
        if organization_data:
            Organization.objects.update_or_create(
                requestor=instance,
                defaults=organization_data
            )
        else:
            # If organization_data is empty, remove existing organization
            Organization.objects.filter(requestor=instance).delete()

        return instance


# Change password functionality for requestor

# class ChangePasswordSerializer(serializers.Serializer):
#     password = serializers.CharField(max_length = 200, required=True)
#     new_password = serializers.CharField(max_length = 200, required=True)
#     class Meta:
#         fields = ['password', 'new_password']

#     def validate_password(self, validated_password):
#         password = validated_password.get(password)
#         new_password = validated_password.get(new_password)
#         user = self.context.get('user')
#         if password != new_password:
#             return Response({"message":"Password and new password does not match"})
#         user.set_password(new_password)
#         user.save()
#         # return validated_password
#         return user



# worked fine

# class ChangePasswordSerializer(serializers.Serializer):
#     password = serializers.CharField(max_length=200, required=True)
#     new_password = serializers.CharField(max_length=200, required=True)
    
#     class Meta:
#         fields = ['password', 'new_password']

#     def validate(self, data):
#         user = self.context.get('user')
#         if not user.check_password(data['password']):
#             raise serializers.ValidationError({"password": "Current password is incorrect"})
#         if data['password'] == data['new_password']:
#             raise serializers.ValidationError({"new_password": "New password must be different from the current password"})
#         return data

#     def save(self):
#         user = self.context.get('user')
#         user.set_password(self.validated_data['new_password'])
#         user.save()
#         return user


# Change password functionality for requestor

class ChangePasswordSerializer(serializers.Serializer):
    password = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True)

    class Meta:
        fields = ['password', 'new_password']


# Forgot password functionality for requestor

# class ForgotPasswordSerializer(serializers.Serializer):
#     email = serializers.EmailField(max_length = 200)

#     class Meta:
#         fields = ['email']


    # def post(self, request):
    #     serializer = ForgotPasswordSerializer(data = request.data)
    #     if serializer.is_valid():
    #         email = serializer.validated_data['email']
    #         try:
    #             user = User.objects.get(email = email)
    #             uid = urlsafe_base64_encode(force_bytes(user.id))
    #             print('Encoded UID', uid)
    #             token = PasswordResetTokenGenerator().make_token(user)
    #             print('Password Reset Token', token)
    #             link = 'http://localhost:3000/api/user/reset/'+uid+'/'+token
    #             print('Password Reset Link', link)
    #             # return request
    #             return Response({"message":"Hi all"})
            
    #         except User.DoesNotExist:
    #             return Response({"message": "User with this email does not exist"})

class SendPasswordResetEmailSerializer(serializers.Serializer):
    email = serializers.EmailField(max_length = 200)

    class Meta:
        fields = ['email']

    def validate(self, attrs):
        email = attrs.get('email')
        if User.objects.filter(email = email).exists():
            user = User.objects.get(email = email)
            uid = urlsafe_base64_encode(force_bytes(user.id))
            print('Encoded UID', uid)
            token = PasswordResetTokenGenerator().make_token(user)
            print('Password Reset Token', token)
            link = 'http://localhost:3000/api/user/reset/'+uid+'/'+token
            print('Password Reset Link', link)
            
            # Send email code here
            body = ('Click on the link to reset your password ' + link)
            data = {
                'subject' : 'Password Reset',
                'body' : body,
                'to_email' : user.email
            }
            Util.sendEmail(data)

            return attrs

        else:
            raise ValidationErr('You are not a registered user')
        
class UserPasswordResetSerializer(serializers.Serializer):
    password = serializers.CharField(max_length = 200)
    confirm_password = serializers.CharField(max_length =200)
    class Meta:
        fields = ['password', 'confirm_password']

    def validate(self, attrs):
        try:
            password = attrs.get('password')
            confirm_password = attrs.get('confirm_password')
            # user = User.objects.get('user')
            uid = self.context.get('uid')
            token = self.context.get('token')
            if password != confirm_password:
                raise serializers.ValidationError('Password and Confirm Password does not match')
            id = smart_str(urlsafe_base64_decode(uid))
            user = User.objects.get(id = id)
            if not PasswordResetTokenGenerator().check_token(user, token):
                raise ValidationErr('Token is not valid or expired')
            user.set_password(password)
            user.save()
            return attrs
        except:
            PasswordResetTokenGenerator().check_token(user, token)
            raise ValidationErr('Token is not valid or expired')

