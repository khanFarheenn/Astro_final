# from django.shortcuts import render

# Create your views here.
from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework import status
from .models import Requestor
from . models import *
# from .serializers import RequestorSerializer, ChangePasswordSerializer, ForgotPasswordSerializer
from .serializers import RequestorSerializer, ChangePasswordSerializer, SendPasswordResetEmailSerializer, UserPasswordResetSerializer
from authentication . models import User

from django.contrib.auth.tokens import default_token_generator
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_str
from django.template.loader import render_to_string
from django.contrib.auth.tokens import PasswordResetTokenGenerator
from django.core.mail import send_mail
from django.conf import settings

# As of 14July24

# from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
# from rest_framework.response import Response
# from django.contrib.auth import update_session_auth_hash
# from .serializers import ChangePasswordSerializer
from rest_framework.views import APIView


class RequestorViewSet(viewsets.ModelViewSet):
    queryset = Requestor.objects.all()
    serializer_class = RequestorSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

    def update(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)

        if getattr(instance, '_prefetched_objects_cache', None):
            # If prefetching has been done, we need to reset the cache.
            instance._prefetched_objects_cache = {}

        return Response(serializer.data)

    def perform_create(self, serializer):
        return serializer.save()


# Change password view for requestor

# class ChangePasswordView(APIView):

    # @api_view(['POST'])
    # @permission_classes([IsAuthenticated])
    # permission_classes = [IsAuthenticated]
    # def change_password(request):
    #     if request.method == 'POST':
    #         serializer = ChangePasswordSerializer(data = request.data, context = {'user':request.user})
    #         if serializer.is_valid():
                # user = request.user
        #         serializer.save()
        #         return Response({"message": "Password changed successfully"})
        # return Response(serializer.errors)
            #     if user.check_password(serializer.data.get('old_password')):
            #         user.set_password(serializer.data.get('new_password'))
            #         user.save()
            #         update_session_auth_hash(request, user)  # To update session after password change
            #         return Response({'message': 'Password changed successfully.'}, status=status.HTTP_200_OK)
            #     return Response({'error': 'Incorrect old password.'}, status=status.HTTP_400_BAD_REQUEST)
            # return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# Worked properly

# class ChangePasswordView(APIView):
#     permission_classes = [IsAuthenticated]

#     def post(self, request, *args, **kwargs):
#         serializer = ChangePasswordSerializer(data=request.data, context={'user': request.user})
#         if serializer.is_valid():
#             serializer.save()
#             return Response({"message": "Password changed successfully"}, status=status.HTTP_200_OK)
#         return Response(serializer.errors)
    

# by study gyaan also working fine

class ChangePasswordView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        serializer = ChangePasswordSerializer(data = request.data)
        if serializer.is_valid():
            user = request.user
            if user.check_password(serializer.data.get('password')):
                user.set_password(serializer.data.get('new_password'))
                user.save()
                # update_session_auth_hash(request, user)  # To update session after password change
                return Response({'message': 'Password changed successfully.'})
            return Response({'error': 'Incorrect old password.'})
        return Response(serializer.errors)
    


# View for Forgot Password

# class ForgotPasswordView(APIView):
#     def post(self, request):
#         serializer = ForgotPasswordSerializer(data = request.data)
#         if serializer.is_valid():
#             email = serializer.validated_data['email']
#             try:
#                 user = User.objects.get(email = email)
#                 uid = urlsafe_base64_encode(force_bytes(user.id))
#                 print('Encoded UID', uid)
#                 token = PasswordResetTokenGenerator().make_token(user)
#                 print('Password Reset Token', token)
#                 link = 'http://localhost:3000/api/user/reset/'+uid+'/'+token
#                 print('Password Reset Link', link)
#                 # return request
#                 return Response({"message":"Hi all"})
            
#             except User.DoesNotExist:
#                 return Response({"message": "User with this email does not exist"})
            
            
        #     token = default_token_generator.make_token(user)
        #     uid = urlsafe_base64_encode(force_bytes(user.pk))
        #     reset_link = f"{settings.FRONTEND_URL}/resetpassword/{uid}/{token}/"
        #     subject = "Password Reset Request"
        #     message = "Please click on the below link to reset your password"
        #     return Response({"message": "Password reset email sent"})
        # return Response(serializer.errors)



class SendResetPasswordEmailView(APIView):
    def post(self, request):
        serializer = SendPasswordResetEmailSerializer(data = request.data)
        if serializer.is_valid():
            return Response({"message":"Password Reset link send, please check your email"})
        return Response(serializer.errors)
    
class UserPasswordResetView(APIView):
    def post(self, request, uid, token):
        # pass
        serializer = UserPasswordResetSerializer(data = request.data, context={'uid':uid, 'token':token})
        if serializer.is_valid():
            return Response({"message":"Password Reset successfully"})
        return Response(serializer.errors)

