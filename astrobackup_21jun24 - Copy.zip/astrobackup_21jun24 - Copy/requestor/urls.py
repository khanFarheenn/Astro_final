# from django.urls import path
# from . import views

# urlpatterns = [
   
# ]

from rest_framework.routers import DefaultRouter
from django.urls import path, include
# from .views import RequestorViewSet, ChangePasswordView, ForgotPasswordView
from .views import RequestorViewSet, ChangePasswordView, SendResetPasswordEmailView, UserPasswordResetView

router = DefaultRouter()
router.register(r'requestors', RequestorViewSet)

urlpatterns = [
    path('', include(router.urls)),
    path('changepassword/', ChangePasswordView.as_view(), name ='changepassword'),

    path('send_password_reset_email/', SendResetPasswordEmailView.as_view(), name ='send_password_reset_email'),

    path('reset_password/<uid>/<token>/', UserPasswordResetView.as_view(), name = 'reset_password'),

    # path('forgotpassword/', ForgotPasswordView.as_view(), name ='forgotpassword'),
]
