#from django.shortcuts import render
from rest_framework import viewsets
# from .models import Test
from .models import *
# from .serializers import TestSerializer
from . serializers import *


# Create your views here.

# ----------- Create view for Test ------------

class TestView(viewsets.ModelViewSet):
    queryset = Test.objects.all()
    serializer_class = TestSerializer



# ----------- Create view for TestCategory ----------

class TestCategoryView(viewsets.ModelViewSet):
    queryset = TestCategory.objects.all()
    serializer_class = TestCategorySerializer




# ----------- Create view for Condition ------------

class ConditionView(viewsets.ModelViewSet):
    queryset = Condition.objects.all()
    serializer_class = ConditionSerializer




# ----------- Create view for TestObject ------------

class TestObjectView(viewsets.ModelViewSet):
    queryset = TestObject.objects.all()
    serializer_class = TestObjectSerializer