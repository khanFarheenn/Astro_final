from rest_framework import serializers
# from . models import Test
from . models import *



# ---------- Create TestSerializer --------

class TestSerializer(serializers.ModelSerializer):
    class Meta:
        model = Test
        fields = '__all__'



# ---------- Create TestCategorySerializer --------

class TestCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = TestCategory
        fields = '__all__'




# ---------- Create ConditionSerializer --------

class ConditionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Condition
        fields = '__all__'





# ---------- Create TestObjectSerializer --------

class TestObjectSerializer(serializers.ModelSerializer):
    class Meta:
        model = TestObject
        fields = '__all__'