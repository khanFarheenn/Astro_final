from django.urls import path, include
from . import views
from rest_framework.routers import DefaultRouter
# from .views import TestView
from .views import *
from rest_framework import viewsets

router = DefaultRouter()

router.register(r'test', TestView)
router.register(r'testCategory', TestCategoryView)
router.register(r'condition', ConditionView)
router.register(r'testObject', TestObjectView)


urlpatterns = [
   path('', include(router.urls))
]