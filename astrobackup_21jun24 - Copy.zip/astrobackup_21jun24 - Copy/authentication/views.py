from django.shortcuts import render
from rest_framework.views import APIView
from .serializers import UserSerializer, LoginSerializer
from rest_framework.response import Response
from django.contrib.auth import authenticate
from rest_framework_simplejwt.tokens import RefreshToken


# Create your views here.

class RegisterView(APIView):
    def post(self, request):
        try:
            # data = request.data
            serializer = UserSerializer(data = request.data)
            if serializer.is_valid():
                serializer.save()
                # return Response({f"message":"User registeration successful","data":serializer.data})
                return Response({"message":"User registeration successful"})
            # return Response({f"message": "Something went wrong","data":serializer.errors})
            return Response({"message": "Something went wrong"})
        
        except Exception as e:
            return Response({"message":"User registerstion unsuccessful"})
            # print(e)
        


class LoginView(APIView):
    def post(self, request):
        try:
            serializer = LoginSerializer(data = request.data)
            if serializer.is_valid():
                email = serializer.data['email']
                password = serializer.data['password']

                user = authenticate(email = email, password = password)
                if user is not None:
                    return Response({"message": "Login successful"})
                return Response({"message":"Enter valid credentials"})
                

                # refresh = RefreshToken.for_user(user)

                # return {
                #     'refresh': str(refresh),
                #     'access': str(refresh.access_token),
                # }


            # return Response({f"message": "Something went wrong","data":serializer.errors})
            return Response({"message": "Something went wrong"})
        
        except Exception as e:
            return Response({"message":"User registerstion unsuccessful"})
            print(e)



# {

# "email": "j4@gmail.com",
# "phone_no":"2531429012",
# "password": "j123"

# }


# Task - jwt auth - code - 86cvwqrwe