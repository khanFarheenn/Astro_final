from django.urls import path
# from . views import RegisterView
from . views import *
# from .views import UserListView

from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)

urlpatterns = [
   
#    path('login/', LoginView.as_view()),
#    path('register/', RegisterView.as_view()),



    path('login/', TokenObtainPairView.as_view(), name = 'token_obtain_pair'),
    path('login/refresh/', TokenRefreshView.as_view(), name = 'token_refresh'),
    path('register/', RegisterView.as_view(), name = "register"),


    # path('api/login/', TokenObtainPairView.as_view(), name = 'token_obtain_pair'),
    # path('api/login/refresh/', TokenRefreshView.as_view(), name = 'token_refresh'),
    # path('api/register/', RegisterView.as_view(), name = "sign_up"),
    # path('api/register/', RegisterView.as_view(), name="sign_up"),
    # path('users/', UserListView.as_view(), name='user-list'),
]

# 1.  http://127.0.0.1:8000/auth/register/

# curl -X POST -d "email=test@example.com&password=yourpassword&phone_no=1234567890" http://127.0.0.1:8000/auth/register/

# 2.  http://127.0.0.1:8000/auth/login/

# curl -X POST -d "email=test@example.com&password=yourpassword" http://127.0.0.1:8000/auth/login/


# This is my first user with jwt auth
# {
# "email":"mytest@example.com",
# "password":"mytest123",
# "phone_no":"2531429012"
# }


# {
# "email":"mytest@example.com",
# "password":"mytest123",
# "phone_no":"2531429012",
# "first_name":"mytest",
# "last_name":"mytest"
# }

