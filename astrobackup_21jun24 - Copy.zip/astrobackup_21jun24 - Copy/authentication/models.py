# from django.db import models
# from django.conf import settings
# from django.contrib.auth.models import AbstractUser, PermissionsMixin
# from django.contrib.auth.base_user import BaseUserManager
# from django.core.validators import validate_email
# from django.core.exceptions import ValidationError


# class CustomUserManager(BaseUserManager):
#     """Define a model manager for User model with no username field."""

#     use_in_migrations = True

#     def _create_user(self, email, password, **extra_fields):
#         """Create and save a User with the given email and password."""
#         if not email:
#             raise ValueError("The given email must be set")

#         try:
#             validate_email(email)
#         except ValidationError as e:
#             raise ValueError("please enter a valid email")

#         email = self.normalize_email(email)
#         user = self.model(email=email, **extra_fields)
#         user.set_password(password)
#         user.save(using=self._db)
#         return user

#     def create_user(self, email, password=None, **extra_fields):
#         if password is None:
#             raise ValueError("Password must not be none")
#         extra_fields.setdefault("is_staff", False)
#         extra_fields.setdefault("is_superuser", False)
#         return self._create_user(email, password, **extra_fields)

#     def create_superuser(self, email, password, **extra_fields):
#         """Create and save a SuperUser with the given email and password."""
#         extra_fields.setdefault("is_staff", True)
#         extra_fields.setdefault("is_superuser", True)

#         if extra_fields.get("is_staff") is not True:
#             raise ValueError("Superuser must have is_staff=True.")
#         if extra_fields.get("is_superuser") is not True:
#             raise ValueError("Superuser must have is_superuser=True.")

#         return self._create_user(email, password, **extra_fields)


# class User(AbstractUser, PermissionsMixin):
#     username = None
#     first_name = models.CharField(max_length=100, null=False)
#     last_name = models.CharField(max_length=100, null=False)
#     password = models.CharField(max_length=100, null=False)
#     email = models.EmailField(unique=True, null=False)
#     USERNAME_FIELD = "email"
#     REQUIRED_FIELDS = ["first_name", "last_name"]

#     objects = CustomUserManager()

#     # Define the role relationship
#     role = models.ForeignKey(
#         "Role", blank=True, related_name="user", null=True, on_delete=models.SET_NULL
#     )

#     class Meta:
#         verbose_name = "User"
#         verbose_name_plural = "Users"
#         db_table = "User"

#     def __str__(self):
#         return self.email


# class Role(models.Model):
#     name = models.CharField(max_length=100)

#     def __str__(self):
#         return self.name


from django.db import models
# from director.models import Role
from . models import *
from django.conf import settings
from django.contrib.auth.models import AbstractUser, PermissionsMixin
from django.contrib.auth.base_user import BaseUserManager
from django.core.validators import validate_email
from django.core.exceptions import ValidationError
from director .models import Admin


class CustomUserManager(BaseUserManager):
    """Define a model manager for User model with no username field."""

    use_in_migrations = True

    def _create_user(self, email, password, phone_no, **extra_fields):
        """Create and save a User with the given email and password."""
        if not email:
            raise ValueError("The given email must be set")

        try:
            validate_email(email)
        except ValidationError:
            raise ValueError("Please enter a valid email")

        email = self.normalize_email(email)
        user = self.model(email=email, phone_no=phone_no, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_user(self, email, password=None, phone_no=None, **extra_fields):
        if password is None:
            raise ValueError("Password must not be none")
        extra_fields.setdefault("is_staff", False)
        extra_fields.setdefault("is_superuser", False)
        return self._create_user(email, password, phone_no, **extra_fields)

    def create_superuser(self, email, password, phone_no, **extra_fields):
        """Create and save a SuperUser with the given email and password."""
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)

        if extra_fields.get("is_staff") is not True:
            raise ValueError("Superuser must have is_staff=True.")
        if extra_fields.get("is_superuser") is not True:
            raise ValueError("Superuser must have is_superuser=True.")

        myuser = self._create_user(email, password, phone_no, **extra_fields)
        print(myuser)

        # Creating the Admin instance and linking it to the user
        myadmin = Admin.objects.create(user=myuser, phone_no=phone_no)
        print('\n\n',myadmin,'\n\n')
        myadmin.save()
        return myuser


# Providing role here as of 26jun24

class Role(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name


# creating user here

class User(AbstractUser):
    username = None
    first_name = models.CharField(max_length=100, null=False)
    middle_name = models.CharField(max_length=100, blank=True)
    last_name = models.CharField(max_length=100, null=False)
    password = models.CharField(max_length=100, null=False)
    email = models.EmailField(unique=True, null=False)
    # phone_no = models.CharField(max_length=250, null=False)
    phone_no = models.CharField(max_length=250, null=True)
    # is_verified = models.BooleanField(default = False) # if it is true then only that person will be able to login

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = ['phone_no']

    objects = CustomUserManager()

    def __str__(self):
        return self.email

    # Define the role relationship
    role = models.ManyToManyField(Role, blank=True, related_name="user")

    class Meta:
        verbose_name = "User"
        verbose_name_plural = "Users"
        db_table = "User"


# class Admin(models.Model):
#     user = models.OneToOneField(User, on_delete=models.CASCADE)
#     phone_no = models.CharField(max_length=50)

#     def __str__(self):
#         return f"Admin: {self.user.email}"



























### As of 21jun24 while creating customuser extra fields create admin
### profile while creating the super user ###


# System check identified no issues (0 silenced).
# PS C:\Users\Win10 Pro\Desktop\Astro_17May24\astrobackend_20jun24\ASTRO-DEV-BACKEND> python manage.py makemigrations 
# It is impossible to change a nullable field 'phone_no' on user to non-nullable without providing a default. This is because the database needs something to populate existing rows.
# Please select a fix:
#  1) Provide a one-off default now (will be set on all existing rows with a null value for this column)
#  2) Ignore for now. Existing rows that contain NULL values will have to be handled manually, for example with a RunPython or RunSQL operation.
#  3) Quit and manually define a default value in models.py.
# Select an option:
