from rest_framework import serializers
from . models import User
from . models import Role

from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from rest_framework_simplejwt.views import TokenObtainPairView


class UserSerializer(serializers.ModelSerializer):

    class Meta:
        model = User
        # fields = ["id", "email", "name", "password"]
        # fields = '__all__'

        fields = ["email", "phone_no", "password"]

        # fields = ["email", "name", "password"]

        # fields = ["email", "password"]

    def create(self, validated_data):
        user = User.objects.create(email=validated_data['email'],
                                       phone_no=validated_data['phone_no']
                                         )
        # user = User.objects.create(email = validated_data['email'],
        #                                name = validated_data['name']
        #                                  )
        # user = User.objects.create(email=validated_data['email'])

        user.set_password(validated_data['password'])
        user.save()
        return user
    
class MyCustomTokenSerializer(TokenObtainPairSerializer):
     @classmethod
     def get_token(cls, user):
        token = super().get_token(user)

        # token['role'] = user.role
        # Err Object of type ManyRelatedManager is not JSON serializable

        # token['role'] = str(user.role)
        # {
            # "token_type": "access",
            # "exp": 1720549322,
            # "iat": 1720549022,
            # "jti": "5399c48938494bb18e3a3ebec24b31d7",
            # "user_id": 12,
            # "role": "authentication.Role.None"
            # }

        # token['role'] = Role.objects.get('name')
        # Err too many values to unpack (expected 2)

        # token['role'] = Role.name
        # Err Object of type DeferredAttribute is not JSON serializable

        token['roles'] = list(user.role.values_list('name', flat = True))
        
        # token['roles'] = user.role.values_list('name', flat = True)

        # token['name'] = user.role
        # Err Object of type ManyRelatedManager is not JSON serializable

        return token
     


class LoginSerializer(serializers.ModelSerializer):
    email = serializers.EmailField()
    password = serializers.CharField()

    
